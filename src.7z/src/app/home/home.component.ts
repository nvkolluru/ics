
import { Component, ViewChild } from '@angular/core';
import {Router,RouterModule} from "@angular/router";

@Component({
  selector: 'home-ics',
  templateUrl: './home.component.html'
})
export class HomeComponent {
    currentState:string="";
    constructor(public router:Router) {
      
        }
        ngOnInit() {
            this.currentState=this.router.url;
          
          }
}
