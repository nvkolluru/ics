// import { forEach } from '@angular/router/src/utils/collection';
// import { Injectable, Output, EventEmitter } from '@angular/core';
// import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpClient } from '@angular/common/http';
// import{HttpClientModule} from '@angular/common/http';
// import 'rxjs/Rx';
// import { of } from 'rxjs';
// import {Observable} from 'rxjs/Rx';
// import { map, catchError } from 'rxjs/operators';
// import 'rxjs/add/operator/catch';
// import { Subject } from 'rxjs/Subject';
// import { process, State } from '@progress/kendo-data-query';

// @Injectable()
// export class ICSSummaryService {
//   private baseUrl: string;
//   constructor(private http: HttpClient) {
//     this.baseUrl = 'http://localhost:50187/';
    
//   }
//   public allData = (state: any, grid: any): Observable<any> => {

//     let stateN: State = {
//       skip: state.skip,
//       take: grid.length,
//       sort: state.sort,
//       filter: {
//         logic: state.filter.logic,
//         filters: state.filter.filters
//       }
//     }
//     let GridData = process(grid, stateN);
//     return Observable.of(GridData);
//   }
//   public getBaseUrl(): Observable<any> {
//     console.log("Url " + this.baseUrl);
//     this.baseUrl = "http://localhost:50187/";
    

//     if (this.baseUrl != null) {
//       console.log("Using Base Url");
//       return Observable.of(this.baseUrl);
//     } else {
//       console.log("Loading Base Url");
//       return (this.http.get('/src/config/hostConfig.json')
//         .pipe(map(response=> {
//           return response;
//         }))
//         .pipe(catchError(this.handleError)).map((res) => {
//           this.baseUrl = res;
//           console.log(this.baseUrl);
//           return of(this.baseUrl);
//         }));
//     }
//   }

//   handleError(error: any) {
//     const errorMsgs = [];
//     const errorFields = [];
//     if (error) {
//       if (error.status) {
//         const uri = error.url || '';
//         if (error.status === 404) {
//           throw new Error(uri + ' Not Found');
//         }
//         if (error.status === 401) {
//           throw new Error(uri + ' Not Authorized');
//         }
//         if (error.status === 500) {
//           return Observable.throw({ 'messages': error.json().error });
//         }
//         if (error.status >= 501 && error.status <= 505) {
//           throw new Error(uri + ' Service Outage');
//         }
//       }
//       if (error.json()) {
//         if (error.json().errors) {
//           for (const err of error.json().errors) {
//             errorFields.push(err.field);
//             errorMsgs.push(err.defaultMessage + ' ' + err.field);
//           }
//         } else if (error.json().message) {
//           return Observable.throw({ 'messages': error.json().message });
//         }
//       }
//     }
//     if (errorFields.length > 0) {
//       return Observable.throw({ 'errorFields': errorFields, 'messages': errorMsgs });
//     }
//     return Observable.throw({ 'messages': ['Server error'] });
//   }

//   getOptions(): RequestOptions {
//     let headers = new Headers({ 'Content-Type': 'application/json' });
//     let options = new RequestOptions({ headers: headers });
//     return options;
//   }
//   updateIncidentSummary(pricingInfo: any): Observable<any> {
//     return this.getBaseUrl().mergeMap((res) => {
//       this.baseUrl = res;
//       return this.http.post(this.baseUrl + 'pricingService/updateCustomer',
//         JSON.stringify(pricingInfo), this.getOptions())
//         .map(res => res.text())
//     });

//     }
// }