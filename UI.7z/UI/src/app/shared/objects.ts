export class icsadmin{
    Name :string
    ADID:string
    Home_Area:string
  }